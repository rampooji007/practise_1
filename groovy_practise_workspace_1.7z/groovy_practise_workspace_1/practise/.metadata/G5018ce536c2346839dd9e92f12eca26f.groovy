 
		
		import java.util.Random;
           import java.util.ArrayList;
           import java.util.Date;
           import java.text.SimpleDateFormat;
           import java.util.Calendar;
		
		list = new ArrayList()
		map = new HashMap()
		Random rnd = new Random()
		
		f_rnd =rnd.nextInt(100);
		l_rnd =rnd.nextInt(100);
		g_rnd =rnd.nextInt(2);
		h_rnd=rnd.nextInt(200-140)+140;
		b_rnd=rnd.nextInt(4000-1000)
		
		
		map.put("firstname", f_list.get(f_rnd).toString())
		map.put("lastname", l_list.get(l_rnd).toString())
		map.put("Gender", G_list.get(g_rnd).toString())
		map.put("Height", h_rnd)
		
		Calendar c = Calendar.getInstance();
		start_date = new SimpleDateFormat("yyyy-mm-dd").parse("1950-01-01");
		c.setTime(start_date);
		c.add(Calendar.DATE,b_rnd)
		m_birthdate = new SimpleDateFormat("yyyy-MM-dd").format(c.getTime());
		
		map.put("BirthDate",m_birthdate.toString())
		list.add(map)
		
		json_map_value = new com.google.gson.Gson().toJson(map)
		
		println json_map_value
				
		