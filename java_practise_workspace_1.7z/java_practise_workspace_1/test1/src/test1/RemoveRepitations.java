package test1;

public class RemoveRepitations {
public static String transform(String input)
{
	return input.replaceAll("(.)\\1{1,}", "$1");
	
}
public static void main(String[] args) {
	System.out.println(RemoveRepitations.transform("abbcbbb"));
}
}
