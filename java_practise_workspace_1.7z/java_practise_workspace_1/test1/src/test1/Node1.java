package test1;

class Node1 {
    private Node1 leftChild, rightChild;
    
   static Node1 root = new Node1();
    
    
    public Node1() {
              super();
       }

       public Node1(Node1 leftChild, Node1 rightChild) {
        this.leftChild = leftChild;
        this.rightChild = rightChild;
    }
    
    public Node1 getLeftChild() {
        return this.leftChild;
    }
    
    public Node1 getRightChild() {
        return this.rightChild;
    }

    public int height() {         
       
       
       if(leftChild==null&&rightChild==null)
    	   return 0;
       else
       {
    	   int leftHeight=(leftChild==null?0:leftChild.height());
    	   int rightHeight=(rightChild==null?0:rightChild.height());
    	   return Math.max(leftHeight, rightHeight)+1;
       }
       
        //throw new UnsupportedOperationException("Waiting to be implemented.");
    }

    public static void main(String[] args) {
       
        Node1 leaf1 = new Node1(null, null);
        Node1 leaf2 = new Node1(null, null);
        Node1 node1 = new Node1(leaf1, null);
        root = new Node1(node1, leaf2);

        System.out.println(root.height());
    }
}
