package test1;

import java.util.Deque;
import java.util.LinkedList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Paragraph {
public static String changeFormat(String format)
{
	Deque<String> d= new LinkedList<>();
	d.addFirst("e");
	d.removeFirst();
	String pat="(\\d{3}\\-\\d{2}\\-\\d{4})";
	Pattern pat1=Pattern.compile(pat);
	Matcher mat1=pat1.matcher(format);
	while(mat1.find())
	{
		String msg=format.replaceAll(".*(\\d{3}\\-\\d{2}\\-\\d{4}).*","$1");
		System.out.println(msg);
		String arr[]=msg.split("-");
		String ret=arr[0]+"/"+arr[2]+"/"+arr[1];
		System.out.println(ret);
		return format.replaceAll("(\\d{3}\\-\\d{2}\\-\\d{4})", ret);
	}
	return "format";
}
public static void main(String[] args) {
	System.out.println(changeFormat("please quote your policy:112-39-8552."+"please quote your no:112-39-8552."));
}
}
