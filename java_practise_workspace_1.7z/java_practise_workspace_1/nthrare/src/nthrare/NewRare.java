package nthrare;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map.Entry;

public class NewRare {
	public static int nthRare(int[] elements,int n)
    {
	 HashMap<Integer,Integer> map=new HashMap<Integer,Integer>();
	 List<Integer> list=new ArrayList<Integer>();	 
	 for(int ele : elements)
	 {
		 Integer count=map.get(ele);
		 if(count==null)
			 count = 0;
		 map.put(ele, count+1);
	 }
	 Iterator<Entry<Integer,Integer>> itr=map.entrySet().iterator();
	 while(itr.hasNext())
	 {
		 Entry<Integer,Integer> entry =itr.next();
		 list.add(entry.getValue());		 
	 }
	 Collections.sort(list);
	 
	 for(int nums : map.keySet())
	 {
		 if(map.get(nums)==list.get(n-1))
			 return nums;
	 }
	 
	 
	        return -1;
    }
    public static void main (String[] args) {
       int x= nthRare(new int[]{5,4,3,3,5,5,5,2,2,2},3);
       System.out.println(x);
    }	
}
