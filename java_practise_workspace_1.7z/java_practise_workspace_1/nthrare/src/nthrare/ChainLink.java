package nthrare;

enum Side { NONE, LEFT, RIGHT }
public class ChainLink {
    private ChainLink left, right;
    
    public void append(ChainLink rightPart) {
        if (this.right != null)
            throw new IllegalStateException("Link is already connected.");
        this.right = rightPart;
        rightPart.left = this;
    }
    
    public Side longerSide() {
    	ChainLink obj=this;
    	int lc=0, rc=0;
    	while(obj.left!=null && obj.left!=this)
    	{
    		lc++;
    		obj=obj.left;
    	}
    	obj=this;
    	while(obj.right!=null && obj.right!=this)
    	{
    		rc++;
    		obj=obj.right;
    	}
    	
    	if(lc>rc)
    		return Side.LEFT;
    	else if(rc>lc)
    		return Side.RIGHT;
    	else
    		return Side.NONE;
    	
    }
    
    public static void main(String[] args) {
        ChainLink left = new ChainLink();
        ChainLink middle = new ChainLink();
        ChainLink right = new ChainLink();
        left.append(middle);
        middle.append(right);
        System.out.println(left.longerSide());
    }
}
