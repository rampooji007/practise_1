package nthrare;

import java.util.List;
import java.util.Arrays;
import java.util.Collections;

public class MaxSum {
    public static int findMaxSum(List<Integer> list) {
    	Collections.sort(list);
    	int len=list.size();
    	
    	if(len==1)
    		return list.get(0);
    	else if(len>1)
    		return list.get(len-1)+list.get(len-2);
    	
        return -1;
    }
    
    public static void main(String[] args) {
        List<Integer> list = Arrays.asList(5, 9, 7, 11);
        System.out.println(findMaxSum(list));
    }
}    
