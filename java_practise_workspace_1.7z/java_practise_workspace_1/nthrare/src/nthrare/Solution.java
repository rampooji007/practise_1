package nthrare;

public class Solution {
	 public static boolean solution (int[] A)
	    {
	        int count=0;
	        for(int i=1;i<A.length;i++)
	        {	            
	            if(A[i]<A[i-1])
	                count++;	            
	        }
	        if(count==1)
	            return true;
	        else
	            return false;
	    }
	    
	    public static void main (String[] args) {
	        System.out.println(solution(new int[] {1,5,3,3,7,3}));
	    }
}
