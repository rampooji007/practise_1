package nthrare;

import java.util.HashMap;

public class Rare {
	 public static int nthRare(int[] elements,int n)
	    {
		 HashMap<Integer,Integer> list=new HashMap<Integer,Integer>();
	        
	       for(int number : elements)
	       {
	    	   int count=0;    	  
	        for(int num : elements)
	        {	        	
	        	if(num==number)
                    count++;
	        }
	        	list.put(count, number);
	        
	        	System.out.println(list);
	       }
	       
	       return list.get(n);
	        
	    }
	    public static void main (String[] args) {
	       int x= nthRare(new int[]{5,4,3,2,1,5,4,3,2,5,4,3,5,4,5},1);
	       System.out.println(x);
	    }	
}
