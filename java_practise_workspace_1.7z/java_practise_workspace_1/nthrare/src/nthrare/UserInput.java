package nthrare;

public class UserInput {
    static String word;
    public static class TextInput {
       
        void add(char c)
        {
            if(word==null)
                word=Character.toString(c);
             else
                word+=Character.toString(c);
        }
        
         String getValue() 
         {
              System.out.println(word);
             return word;
         }
    }

    public static class NumericInput extends TextInput{

           @Override
        void add(char c)
        {
             if(Character.isDigit(c))
             {
                if(word==null)
                word=Character.toString(c);
             else
                word+=Character.toString(c);     
             }
            
        }
         @Override
         String getValue() 
         {
              System.out.println(word);
             return word;
         }
    }

    public static void main(String[] args) {
        TextInput input = new NumericInput();
        input.add('1');
        input.add('a');
        input.add('0');
        System.out.println(input.getValue());
    }
}