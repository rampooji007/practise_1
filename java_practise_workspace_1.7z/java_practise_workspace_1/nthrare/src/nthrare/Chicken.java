package nthrare;

import java.util.concurrent.Callable;

interface IBird {
Egg Lay();
}

class Chicken implements IBird{
public Chicken() {
	System.out.println("test 1");
}
@Override
public Egg Lay() {		
	System.out.println("test 2");
	return new Egg(Chicken::new);
	//return new Egg(new Chicken);
} 
    public static void main (String[] args) {
        Chicken chicken = new Chicken();
        Egg object=new Egg(null);
        System.out.println(object instanceof IBird);
        System.out.println(chicken instanceof IBird);
    }
	   
}
class Egg<B extends IBird>
{
	Callable<B> createBird;
	public Egg(Callable<B> createBird)
	{
		System.out.println("test 3");
		this.createBird = createBird;
	}
	public B hatch() throws Exception 
	{
		if (createBird == null)
			throw new IllegalStateException();
		try 
		{
			
			return createBird.call();
		} 
		finally 
		{
			createBird = null;
		}
	}
}

