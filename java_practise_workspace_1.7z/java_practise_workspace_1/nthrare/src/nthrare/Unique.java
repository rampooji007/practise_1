package nthrare;



import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.ArrayList;
import java.util.Arrays;

public class Unique {
    public static Collection<Integer> findUniqueNumbers(Collection<Integer> numbers) {
       ArrayList<Integer> a= new ArrayList<>(numbers);
       int temp=0;
       for(int i=0;i<a.size()-1;i++)
       {
    	   temp=a.get(i);
    	   i--;
    	   if(a.indexOf(temp)!=a.lastIndexOf(temp))
    	   {
    	   while(a.contains(temp))
    	   {
    		   a.remove(new Integer(temp));
    	   }
    	   }
       }
       return a;
    }


    public static void main(String[] args) {
        Collection<Integer> numbers = Arrays.asList(1, 2, 3,3,5,5);
        for (int number : findUniqueNumbers(numbers))
            System.out.println(number);
    }
}


