package nthrare;

import java.util.ArrayList;
import java.util.Collection;
import java.util.LinkedHashSet;
import java.util.List;

public class Friends
{
    String s;
    ArrayList<Friends> friends=new ArrayList<Friends>();
    public Friends(String s)
    {
        this.s=s;
    }
    public Collection<Friends> getFriends()
    {
        return friends;
    }
    public void addFriends(Friends f)
    {
        friends.add(f);
        f.getFriends().add(this);
    }
    public Boolean canBeConnected(Friends f)
    {
        
        LinkedHashSet<Friends> s=new LinkedHashSet<Friends>();
        List<Friends> list = new ArrayList<Friends>();
        s.add(this);
        s.addAll(this.getFriends());
        list.addAll(s);
        for(int i=1;i<list.size();i++)
        {
        	s.addAll(list.get(i).getFriends());
        	list.clear();
        	list.addAll(s);        	
        }
        if(list.contains(f))
        	return true;
        
            return false;
}
    public static void main(String[] args) {
        Friends a=new Friends("A");
        Friends b=new Friends("B");
        Friends c=new Friends("C");
        Friends d=new Friends("D");
        Friends e=new Friends("E");
        Friends f=new Friends("F");
        Friends g=new Friends("G");
        a.addFriends(b);
        b.addFriends(c);
        c.addFriends(d);
        d.addFriends(a);
        d.addFriends(e);
        e.addFriends(f);
        
        System.out.println(a.canBeConnected(f));
    }
}


