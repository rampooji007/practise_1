package nthrare;

public class GFG {
	  public static int minimalNumberPackages(int iteams,int alp,int asp)
	    {
	      
	        if(asp==0)
	        {
	            if(iteams%5==0 && alp>=1)
	            {
	                return iteams/5;
	            }
	            else{
	                return -1;
	            }
	        }else if(iteams<=5)
	        {
	            if(iteams==5 && alp>=1)
	            {
	                return 1;
	            }
	            else
	            {
	             if(iteams>asp)
	             {
	                 return -1;
	             }else
	             {
	                 return iteams;
	             }
	            }
	        }else
	        {
	            int alps=(alp*5);
	           int packages=alps+asp;
	           if(iteams>packages)
	           {
	               return -1;
	           }else
	           {
	               if(alps<iteams&&alp!=0&&asp==0)
	               {
	               int remtemp=iteams%alps;
	               return remtemp+alp;
	               }
	               else if(alp!=0)
	               {	    
	            	   if(alps>iteams)
	            	   {
	            	   System.out.println("control");
	            	   int largePackages=  iteams/5;	                  
	                   int remainingPackages=iteams-(largePackages*5);
	                   if(remainingPackages==asp) 
	                   {
	                	   return largePackages+remainingPackages;
	                   }
	                   else
	                   {
	                	   return -1;
	                   }
	                	   
	            	   }
	            	   else if(alps<iteams)
	            	   {
	            		   int largePackages=iteams-alps;
	            		   return largePackages+alp;
	            	   }else
	            	   {
	            		   return -1;
	            	   }
	               }else{
	                   return iteams;
	               }
	           }
	        }
			

	    }

	public static void main (String[] args) 
	{ 
	System.out.println(minimalNumberPackages(26,3,6));
	} 
}
