package nthrare;

public class Path {

}
