package nthrare;

public class RemoveRepetitions {
    public static String transform(String input) {
        //throw new UnsupportedOperationException("Waiting to be implemented.");
	return input.replaceAll("(.)\\1{1,}", "$1");
    }
    
    public static void main(String[] args) {
        System.out.println(RemoveRepetitions.transform("abbcbbb"));        
    }
}