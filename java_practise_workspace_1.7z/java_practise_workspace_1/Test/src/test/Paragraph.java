package test;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Paragraph {
    public static String changeFormat(String paragraph) {
    	String pat="(\\d{3}\\-\\d{2}\\-\\d{4})";
        
        Pattern p=Pattern.compile(pat);
        Matcher m=p.matcher(paragraph);
        
    while(m.find())
    {
        String msg= paragraph.replaceAll(".*(\\d{3}\\-\\d{2}\\-\\d{4}).*", "$1");
        String[] arr=msg.split("-");
        String ret=arr[0]+"/"+arr[2]+"/"+arr[1];
        return paragraph.replaceAll( "(\\d{3}\\-\\d{2}\\-\\d{4})",ret);
    }
    return "f";
    }
    public static void main(String[] args) {
        System.out.println(changeFormat("Please quote your policy number: 112-39-8552."
        		+ " Please quote your policy number: 112-39-8552."));
    }
}













//  System.out.println("pp"+paragraph);
//   String[] m1=paragraph.split("(\\d{3}\\-\\d{2}\\-\\d{4})");
//  System.out.println(m1[0]+"hello");
 // System.out.println(m1[1]+"1");
//  String message=m1[0]+arr1+m1[1];
 /* String message = "";     
  
  for(String word : m1)
  {
  	System.out.println(word);
  }
  
  for(int i=0;i<m1.length-1;i++)
  {        	        	
  	 message+=m1[i]+arr1+m1[i+1];
  	 i++;
  }
  if(m1.length>2)
  message+=arr1+m1[m1.length-1];*/
  
 // System.out.println(m1[2]);