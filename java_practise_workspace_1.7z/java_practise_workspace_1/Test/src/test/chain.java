package test;

public class chain {
    public static int minPieces(int[] original, int[] desired) {
    	int minimumPieces = 0;
        int oposition = 0;

        
        int desiredPosition = 0;
        for (int i = 0; i < desired.length; i++) {
            int ElementFromDesiredList = desired[desiredPosition];

            
            for (int O = 0; O < original.length; O++) {
                if (original[O] == ElementFromDesiredList) {
                    minimumPieces += 1;
                    System.out.println("Count was : " + minimumPieces);
                    oposition = O;
                    System.out.println("1# Element pushed was " + original[oposition]);
                    break;
                }
            }

            // Check if next element from desired is the next element of original also
            if ((oposition + 1 < original.length) && (desiredPosition + 1 < desired.length)
                    && (desired[desiredPosition + 1] == original[oposition + 1])) {
                // run a loop for remaining elements in original list
                for (int k = oposition + 1; k < original.length; k++) {
                    // check if the next element is same in both lists
                    if (desired[desiredPosition + 1] == original[oposition + 1]) {
                        // push the prev element in the copied list
                        System.out.println("2# Element pushed was " + original[oposition + 1]);

                        // increment the position for both the lists
                        oposition = oposition + 1;
                        desiredPosition = desiredPosition + 1;
                    } else {
                        desiredPosition = desiredPosition + 1;
                        break;
                    }
                }
                desiredPosition = desiredPosition + 1;
            } else if ((oposition + 1 < original.length) && (desiredPosition + 1 < desired.length)
                    && desired[desiredPosition + 1] != original[oposition + 1]) {
                desiredPosition = desiredPosition + 1;
            } else if ((oposition + 1) > original.length) {
                ElementFromDesiredList = desired[desiredPosition + 1];
                System.out.println("3# Element pushed was " + ElementFromDesiredList);
                break;
            } else if (desiredPosition + 1 >= desired.length) {
                i = desired.length;
                return minimumPieces;
            }
        }
        return minimumPieces;
    }

    public static void main(String[] args) {
        int[] original = new int[] { 1, 4, 3, 2 };
        int[] desired = new int[] { 1, 2, 4, 3 };
        System.out.println(chain.minPieces(original, desired));
    }
}