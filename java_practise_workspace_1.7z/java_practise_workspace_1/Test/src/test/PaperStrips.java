package test;


import java.util.*;

public class PaperStrips {	
	    public static int minPieces(int[] original, int[] desired) {
	    	
	    	int count = 0;
	        int opn = 0;

	        
	        int dpn = 0;
	        for (int i = 0; i < desired.length; i++) {
	            int ElementFromDesiredList = desired[dpn];

	            
	            for (int O = 0; O < original.length; O++) {
	                if (original[O] == ElementFromDesiredList) {
	                    count += 1;
	                   
	                    opn = O;	                   
	                    break;
	                }
	            }
	        }
	       return count-1;
	    }

	    public static void main(String[] args) {
	        int[] original = new int[] { 1, 4, 2, 3 };
	        int[] desired = new int[] { 1, 2, 4, 3 };
	        System.out.println(PaperStrips.minPieces(original, desired));
	    }
	}

